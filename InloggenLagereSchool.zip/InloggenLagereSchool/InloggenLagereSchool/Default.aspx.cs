﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Text;
namespace InloggenLagereSchool
{
    public partial class Default : System.Web.UI.Page
    {

        static string ComputeSha256Hash(string rawData)
        {
            using (SHA256 sha256Hash = SHA256.Create())
            {
                // ComputeHash - returns byte array  
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(rawData));

                // Convert byte array to a string   
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                SqlConnection con = new SqlConnection(@"Data Source = localhost; Initial Catalog = groepswerk; Integrated Security = True");
                try
                {

                    con.Open();
                    SqlCommand com = new SqlCommand("Select schoolnaam from TBLschool;", con);
                    SqlDataReader lezer = com.ExecuteReader();

                    while (lezer.Read())
                    {
                        ddlSchool.Items.Add(lezer.GetString(0));

                    }
                }
                catch(Exception ex)
                {
                    lblError.Text=(ex.Message);
                }
                finally
                {
                    con.Close();
                } 
            }
        }

        protected void btnInloggen_Click(object sender, EventArgs e)
        {

            SqlConnection con = new SqlConnection(@"Data Source = localhost; Initial Catalog = groepswerk; Integrated Security = True");

            try
            {
                int aantal = 0;
                int gbAantal = 0;
                
                var GebruikersNaam = txtGebruikersNaam.Text;
                var Wachtwoord = txtWachtwoord.Text;

                con.Open();
                SqlCommand com = new SqlCommand("Select gebruikersnaam from TBLleerkracht;", con);
                SqlDataReader lezer = com.ExecuteReader();

                while (lezer.Read())
                {
                    if (GebruikersNaam == lezer.GetString(0))
                    {
                        
                        lblResultaat.Text = "correcte gebruikersnaam";
                        gbAantal = aantal;
                    }

                    aantal++;
                }
                lezer.Close();
                aantal = 0;
                SqlCommand com2 = new SqlCommand("Select wachtwoord,admin from TBLleerkracht;", con);
                SqlDataReader lezer2 = com2.ExecuteReader();
                while (lezer2.Read())
                {
                    bool admin = false;
                    string plainData = txtWachtwoord.Text;
                    string hashedData = ComputeSha256Hash(plainData);
                    if (lezer2.GetBoolean(1))
                    {
                        admin = true;
                    }
                    if (hashedData == lezer2.GetString(0))
                    {
                        if (aantal == gbAantal)
                        {
                            
                            lblWachtwoord.Text = "correct wachtwoord";
                            if (admin)
                            {

                            }
                        }
                    }
                    
                    aantal++;
                }
                lezer2.Close();
                
            }

            finally
            {
                con.Close();

            }
        }

        protected void btnRegistreren_Click(object sender, EventArgs e)
        {

            string plainData = txtWwRegistreren.Text;
            string hashedData = ComputeSha256Hash(plainData);
            int index = ddlSchool.SelectedIndex + 1;

            using (SqlConnection con = new SqlConnection())
            {
                con.ConnectionString = (@"Data Source=localhost;Initial Catalog=groepswerk;Integrated Security=True");
                int gbID=0;
                using (SqlCommand com = new SqlCommand())
                {

                    com.Connection = con;
                    com.CommandType = System.Data.CommandType.Text;
                    com.CommandText = "INSERT into TBLleerkracht (gebruikersnaam,wachtwoord) VALUES(@Gebruikersnaam,@hashedData);";

                    com.Parameters.AddWithValue("@hashedData", hashedData);
                    com.Parameters.AddWithValue("@Gebruikersnaam", txtGbRegistreren.Text);
                    


                    con.Open();
                    com.ExecuteNonQuery();


                }
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = con;
                    com.CommandType = System.Data.CommandType.Text;
                    com.CommandText = " SELECT gebruikerID FROM TBLleerkracht WHERE gebruikersnaam=@Gebruikersnaam;";
                    com.Parameters.AddWithValue("@Gebruikersnaam", txtGbRegistreren.Text);
                    SqlDataReader lezer = com.ExecuteReader();
                    
                    while (lezer.Read())
                    {
                        gbID = lezer.GetInt32(0);
                        
                    }
                    lezer.Close();
                }
                using (SqlCommand com = new SqlCommand())
                {
                    com.Connection = con;
                    com.CommandType = System.Data.CommandType.Text;
                    com.CommandText = "INSERT INTO TBLleerkrachtPerSchool (gebruikerID,schoolID) VALUES (@gbID,@Index);";
                    com.Parameters.AddWithValue("@gbID", gbID);
                    com.Parameters.AddWithValue("@Index", index);
                    com.ExecuteNonQuery();
                }
            }

        }
    }
}